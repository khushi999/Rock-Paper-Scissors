import random, sys

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''
game_images = [rock, paper, scissors]

player_score = 0
computer_score = 0

while True:

	user_choice = int(
	    input(
	        "\nWhat do you choose?\nType: 0 for rock, 1 for paper or 2 for scissors: "
	    ))

	print(game_images[user_choice])

	print("Computer chose:")
	computer_choice = int(random.randint(0, 2))

	print(game_images[computer_choice])

	if user_choice == computer_choice:
		print("Draw.\n")

	elif user_choice == 0:
		if computer_choice == 1:
			print("You lose.")
			computer_score += 1
		else:
			print("You win.")
			player_score += 1

	elif user_choice == 1:
		if computer_choice == 0:
			print("You win.")
			player_score += 1
		else:
			print("You lose.")
			computer_score += 1

	elif user_choice == 2:
		if computer_choice == 1:
			print("You lose.")
			computer_score += 1
		else:
			print("You win.")
			player_score += 1

	print(f"\nplayer score: {player_score}")
	print(f"computer score: {computer_score}\n\n")

	answer = input("Do you want to continue?\nType yes or no: ").lower()
	if answer == "no":
		sys.exit()
		